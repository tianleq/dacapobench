package com.example.demo;

import com.sun.tools.javac.file.JavacFileManager;
import com.sun.tools.javac.main.Main;
import com.sun.tools.javac.util.Context;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.tools.FileObject;
import javax.tools.ForwardingJavaFileObject;
import javax.tools.JavaFileManager;
import javax.tools.JavaFileObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Path;


@RestController
public class CompilerController {

    private final int SIZE = 4096;


    @GetMapping("/compile")
    public String compile(@RequestParam(name = "file", defaultValue = "") String file) throws IOException {
        final String root = System.getProperty("org.dacapo.spring.javac.root");
        final OutputStream bhos = new ByteArrayOutputStream(SIZE);
        final Context ctx = new Context();

        //JavaFileManager directing all writes to a Blackhole to avoid measurement fluctuations due to delayed filesystem writes
        try (JavacFileManager mngr = new JavacFileManager(ctx, true, null) {
            @Override
            public JavaFileObject getJavaFileForOutput(JavaFileManager.Location arg0, String arg1, JavaFileObject.Kind arg2, FileObject arg3) throws IOException {
                return new ForwardingJavaFileObject<>(super.getJavaFileForOutput(arg0, arg1, arg2, arg3)) {
                    @Override
                    public OutputStream openOutputStream() {
                        return bhos;
                    }
                };
            }
        }) {
            String[] cmdLine = new String[]{"-XDcompilePolicy=simple", "-implicit:none", "-nowarn", "--module-source-path", root, "-d", root, "-XDignore.symbol.file=true", Path.of(root, file).toString()};
            if (new Main("javac").compile(cmdLine, ctx).exitCode != 0) {
//                throw new IOException("compilation failed");
                System.err.println(file + " failed");
            }
        }
        return String.format("%s compiled successfully", file);
    }
}
